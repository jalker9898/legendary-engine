// Jordan Alker LAB ASsignment 3
package labprojectthree;
import java.util.Scanner;
public class LabProjectTHREE {

    public static void main(String[] args) {
    Scanner scan = new Scanner (System.in);
    
    double miles, gallons, quotient;
    
      System.out.print("Enter the vehicle brand you drive: ");
    	String myString = scan.next();
       
  System.out.println("Enter how many miles you have driven in your " +myString);
    miles = scan.nextDouble();
        System.out.println("Enter amount of gallons used"); 
        gallons = scan.nextDouble();
        
        quotient = miles / gallons;
        quotient=Math.round(quotient*100.0)/100.0;
        System.out.println("Your miles per gallon is "+ quotient);
        
        System.out.println("Do you drive a Ford? Please answer Yes or No");
        String Answer = scan.next();
       // String Yeet = "Yes";
       // String Neat = "No";
        //String Yeat = "yes";
//        boolean boo1 = Boolean.parseBoolean(Yeet);
//        boolean boo2 = Boolean.parseBoolean(Neat);
//        boolean boo3 = Boolean.parseBoolean(Answer);
//        boolean boo4 = Boolean.parseBoolean(Yeat);
//        if (boo3 == boo1 || boo3 == boo4)  { 
        // If answer os ues o will equal zero
        int compareResult = Answer.toUpperCase().compareTo("YES"); 
        
        if (Answer.toUpperCase().equals("YES") || Answer.toUpperCase().equals("Y"))
        {
           System.out.println("Don't worry, you'll learn how to be a man one day ");
 
        } 
        else 
        { 
            System.out.println("Awesome!");
        }
    }
}
